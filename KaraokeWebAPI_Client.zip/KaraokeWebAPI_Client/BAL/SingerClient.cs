﻿using KaraokeWebAPI_Client.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace KaraokeWebAPI_Client.BAL
{
    public class SingerClient
    {
        private string _baseURL = "http://localhost:62426/api/";

        public IEnumerable<SingerModel> GetList()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Singers").Result;
                if (response.IsSuccessStatusCode)
                {
                    return response.Content.ReadAsAsync<IEnumerable<SingerModel>>().Result;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
        }
    }
}