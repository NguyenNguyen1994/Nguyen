﻿using KaraokeWebAPI_Client.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace KaraokeWebAPI_Client.BAL
{
    public class GenreClient
    {
        private string _baseURL = "http://localhost:62426/api/";

        public IEnumerable<GenreModel> GetList()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Genres").Result;
                if (response.IsSuccessStatusCode)
                {
                    return response.Content.ReadAsAsync<IEnumerable<GenreModel>>().Result;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
        }
    }
}