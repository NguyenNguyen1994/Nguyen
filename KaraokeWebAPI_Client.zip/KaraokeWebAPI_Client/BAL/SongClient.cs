﻿using KaraokeWebAPI_Client.Models;
using KaraokeWebAPI_Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace KaraokeWebAPI_Client.BAL
{
    public class SongClient
    {
        private string _baseURL = "http://localhost:62426/api/";

        public IEnumerable<SongModel> GetList()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Songs").Result;
                if (response.IsSuccessStatusCode)
                {
                    return response.Content.ReadAsAsync<IEnumerable<SongModel>>().Result;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
        }
    }
}