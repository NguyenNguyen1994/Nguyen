﻿using KaraokeWebAPI_Client.BAL;
using KaraokeWebAPI_Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KaraokeWebAPI_Client.Controllers
{
    public class SongController : Controller
    {
        // GET: Song
        public ActionResult Index()
        {
            SongClient client = new SongClient();
            SongListViewModel list = new SongListViewModel();
            //list.SongList = client.GetList();
            return View(list);
        }
    }
}