﻿using KaraokeWebAPI_Client.BAL;
using KaraokeWebAPI_Client.Models;
using KaraokeWebAPI_Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KaraokeWebAPI_Client.Controllers
{
    public class SongController : Controller
    {
        // GET: Genre
        public ActionResult Index()
        {
            SongClient client = new SongClient();
            SongCreateListViewModel list = new SongCreateListViewModel();
            list.SongList = client.GetList();
            return View(list);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View("Create");
        }

        [HttpPost]
        public ActionResult Create(SongModel song)
        {
            SongClient client = new SongClient();
            client.Create(song);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string songID)
        {
            SongClient client = new SongClient();
            client.Delete(songID);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(string songID)
        {
            SongClient client = new SongClient();
            SongCreateViewModel song = new SongCreateViewModel();
            //song = client.Find(songID);
            return View("Edit", song);
        }

        //[HttpPost]
        //public ActionResult Edit(SongModel song)
        //{
        //    SongClient client = new SongClient();
        //    client.Edit(song);
        //    return RedirectToAction("Index");
        //}
	}
}