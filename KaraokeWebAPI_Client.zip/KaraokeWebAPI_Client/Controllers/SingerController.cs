﻿using KaraokeWebAPI_Client.BAL;
using KaraokeWebAPI_Client.Models;
using KaraokeWebAPI_Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KaraokeWebAPI_Client.Controllers
{
    public class SingerController : Controller
    {
        // GET: Singer
        public ActionResult Index()
        {
            SingerClient client = new SingerClient();
            SingerListViewModel list = new SingerListViewModel();
            list.SingerList = client.GetList();
            return View(list);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View("Create");
        }

        [HttpPost]
        public ActionResult Create(SingerModel singer)
        {
            SingerClient client = new SingerClient();
            client.Create(singer);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string singerID)
        {
            SingerClient client = new SingerClient();
            SongDetailClient songdtClient = new SongDetailClient();
            SongClient songClient = new SongClient();

            var listSongOfSinger = from sdt in songdtClient.GetList()
                                   join singer in client.GetList()
                                   on sdt.SingerID equals singer.SingerID
                                   where singer.SingerID == singerID
                                   select sdt.SongID;
  
            foreach (var songID in listSongOfSinger)
            {
                foreach (var songIDAll in songdtClient.GetList())
                {
                    if(songID.Equals(songIDAll.SongID))
                    {
                        int countID = songdtClient.GetList().Count(x => x.SongID.Equals(songID));
                        if(countID > 1)
                        {
                            if(songIDAll.SingerID.Equals(singerID))
                            {
                                songdtClient.Delete1(songIDAll.SongID, songIDAll.SingerID);
                                client.Delete(songIDAll.SingerID);
                                break;
                            }
                        }
                        else
                        {
                            songdtClient.Delete(songIDAll.SongID);
                            songClient.Delete(songIDAll.SongID);
                            client.Delete(songIDAll.SingerID);
                        }
                    }
                }
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(string singerID)
        {
            SingerClient client = new SingerClient();
            SingerModel singer = new SingerModel();
            singer = client.Find(singerID);
            return View("Edit", singer);
        }

        [HttpPost]
        public ActionResult Edit(SingerModel singer)
        {
            SingerClient client = new SingerClient();
            client.Edit(singer);
            return RedirectToAction("Index");
        }
    }
}