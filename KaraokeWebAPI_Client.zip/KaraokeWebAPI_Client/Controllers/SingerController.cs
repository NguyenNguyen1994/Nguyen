﻿using KaraokeWebAPI_Client.BAL;
using KaraokeWebAPI_Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KaraokeWebAPI_Client.Controllers
{
    public class SingerController : Controller
    {
        // GET: Singer
        public ActionResult Index()
        {
            SingerClient client = new SingerClient();
            SingerListViewModel list = new SingerListViewModel();
            list.SingerList = client.GetList();
            return View(list);
        }
    }
}