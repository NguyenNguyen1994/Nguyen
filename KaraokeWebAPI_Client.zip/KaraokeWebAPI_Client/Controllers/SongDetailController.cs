﻿using KaraokeWebAPI_Client.BAL;
using KaraokeWebAPI_Client.Models;
using KaraokeWebAPI_Client.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using PagedList.Mvc;

namespace KaraokeWebAPI_Client.Controllers
{
    public class SongDetailController : Controller
    {
        //
        // GET: /SongDetail/
        public ActionResult Index(int? page)
        {
            SongDetailClient client = new SongDetailClient();
            //SongDetailListViewModel list = new SongDetailListViewModel();
            //list.SongDetailList = client.GetList().ToPagedList(page ?? 1, 3);             
            return View(client.GetList().ToPagedList(page ?? 1, 3));
        }

        [HttpGet]
        public ActionResult Create()
        {
            SongClient clientSong = new SongClient();
            SingerClient clientSinger = new SingerClient();

            var listClient = clientSong.GetList();
            var list = (from item in listClient
                        select new SongViewModel
                        {
                            SongID = item.SongID,
                            SongName = item.SongName
                        }).OrderBy(x=>x.SongName);

            var listClient1 = clientSinger.GetList();
 

            ViewBag.SongList = list.GroupBy(x => x.SongID).Select(g => g.FirstOrDefault()).ToList();
            ViewBag.SingerList = listClient1.OrderBy(x => x.SingerName).ToList();

            return View("Create");
        }

        [HttpPost]
        public ActionResult Create(string _songID, string _listID)
        {
            string[] ListSingerID = _listID.Split(',');
            for(int i = 0; i< ListSingerID.Length; i++)
            {
                Models.SongDetailModel songDT = new Models.SongDetailModel();
                songDT.SongID = _songID;
                songDT.SingerID = ListSingerID[i];
                SongDetailClient client = new SongDetailClient();
                client.Create(songDT);
            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(ViewModel.SongDetailModel s)
        {
            SongDetailClient client = new SongDetailClient();
            client.Delete(s.SongID);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(string songID)
        {
            SongDetailClient client = new SongDetailClient();
            List<Models.SongDetailModel> listSong = new List<Models.SongDetailModel>();
            listSong = client.Find(songID).ToList();
            ViewBag.listSinger = listSong.Select(x => x.SingerID).ToList();
            //
            SingerClient singerClient = new SingerClient();
            ViewBag.listSingerAll = singerClient.GetList().Select(x=>x.SingerID).ToList();
            ViewBag.listSingerAllName = singerClient.GetList();
            //
            GenreClient genreClient = new GenreClient();
            ViewBag.listGenre = genreClient.GetList();
            //
            SongClient sc = new SongClient();
            SongCreateViewModel sm = sc.Find(songID).ToList().First();
            SongModel smm = new SongModel() { SongID = sm.SongID, GenreID = sm.GenreID, SongName = sm.SongName, DateUpload = sm.DateUpload, ViewsCount = sm.ViewsCount };
            return View("Edit", smm);
        }

        [HttpPost]
        public ActionResult Edit(string _listID, SongModel song, string _genreID)
        {
            SongClient client = new SongClient();
            song.DateUpload = client.GetList().Where(x => x.SongID == song.SongID).Select(x => x.DateUpload).FirstOrDefault();
            song.ViewsCount = client.GetList().Where(x => x.SongID == song.SongID).Select(x => x.ViewsCount).FirstOrDefault();
            song.GenreID = _genreID;
            client.Edit(song);
            SongDetailClient client1 = new SongDetailClient();
            client1.Delete(song.SongID);

            string[] ListSingerID = _listID.Split(',');
            for (int i = 0; i < ListSingerID.Length; i++)
            {
                Models.SongDetailModel songDT = new Models.SongDetailModel();
                songDT.SongID = song.SongID;
                songDT.SingerID = ListSingerID[i];
                
                client1.Create(songDT);
            }
            return RedirectToAction("Index","Song");
        }
    }
}