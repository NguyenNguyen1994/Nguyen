﻿/// <reference path="../angular.min.js" /> 
/// <reference path="Modules.js" />
/// <reference path="Services.js" />

app.controller("CRUD_AngularJs_RESTController", function ($scope, CRUD_AngularJs_RESTService) {

    GetAllRecords();
    function GetAllRecords() {
        var promiseGet = CRUD_AngularJs_RESTService.getAllSinger();
        promiseGet.then(function (pl) {
            $scope.myData = pl.data;
            //alert($scope.myData.length)
        },
              function (errorPl) {
                  $log.error('Some Error in Getting Records.', errorPl);
              });
    }

    $scope.showModal = false;
    $scope.id = "";

    $scope.getAllSong = function (SingerID) {
        $scope.showModal = true;
        $scope.id = SingerID;
        alert(SingerID);
        var promiseGet = CRUD_AngularJs_RESTService.getAllSong(SingerID);
        promiseGet.then(function (pl) {
            $scope.songOfSinger = pl.data;
            //alert($scope.songOfSinger.length)
        },
              function (errorPl) {
                  $log.error('Some Error in Getting Records.', errorPl);
              });
        alert($scope.list.length);
    };

    $scope.close = function () {
        $scope.showModal = false;
        $scope.Vids = [];
    };

    $scope.Vids = {
        myData: $scope.myData,
        myData1: $scope.myData1
    };


    
    //$scope.changID = function (id) {
    //    $scope.id = id;
    //}

    GetAllRecords1();
    function GetAllRecords1() {
        var promiseGet = CRUD_AngularJs_RESTService.getAllSinger();
        
        promiseGet.then(function (pl) {
            $scope.$scope.myData1 = pl.data;
            //alert($scope.myData.length)
        },
              function (errorPl) {
                  $log.error('Some Error in Getting Records.', errorPl);
              });
    }
})