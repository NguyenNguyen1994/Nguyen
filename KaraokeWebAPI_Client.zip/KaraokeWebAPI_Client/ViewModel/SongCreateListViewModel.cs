﻿using KaraokeWebAPI_Client.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI_Client.ViewModel
{
    public class SongCreateListViewModel
    {
        public IEnumerable<SongModel> SongList { get; set; }
        public IEnumerable<SingerOfSongViewModel> ListSingerOfSong { get; set; }
    }
}