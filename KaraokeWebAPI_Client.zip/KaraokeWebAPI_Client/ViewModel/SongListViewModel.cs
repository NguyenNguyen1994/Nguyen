﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI_Client.ViewModel
{
    public class SongListViewModel
    {
        public IEnumerable<SongViewModel> SongList { get; set; }
    }
}