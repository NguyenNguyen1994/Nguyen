﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(KaraokeWebAPI_Client.Startup))]
namespace KaraokeWebAPI_Client
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
