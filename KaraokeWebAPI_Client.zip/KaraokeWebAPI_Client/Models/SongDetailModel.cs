﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI_Client.Models
{
    public class SongDetailModel
    {

        [StringLength(50)]
        public string SongID { get; set; }

        [StringLength(50)]
        public string SingerID { get; set; }
    }
}