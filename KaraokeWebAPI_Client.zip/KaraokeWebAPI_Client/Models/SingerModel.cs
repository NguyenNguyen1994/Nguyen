﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI_Client.Models
{
    public class SingerModel
    {
        public string SingerID { get; set; }
        public string SingerName { get; set; }
    }
}