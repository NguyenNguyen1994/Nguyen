﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI_Client.Models
{
    public class GenreModel
    {
        [StringLength(50)]
        public string ID { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }
    }
}