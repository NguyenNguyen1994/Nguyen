﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI_Client.Models
{
    public class SongModel
    {

        public string SongID { get; set; }


        public string SongName { get; set; }


        public string GenreID { get; set; }

        public DateTime? DateUpload { get; set; }

        public int? ViewsCount { get; set; }
    }
}