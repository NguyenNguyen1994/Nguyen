﻿using KaraokeWebAPI_Client.Areas.Admin.BAL;
using KaraokeWebAPI_Client.Areas.Admin.Models;
using KaraokeWebAPI_Client.Areas.Admin.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KaraokeWebAPI_Client.Areas.Admin.Controllers
{
    public class GenreController : Controller
    {
        // GET: Genre
        public ActionResult Index()
        {
            GenreClient client = new GenreClient();
            GenreListViewModel list = new GenreListViewModel();
            list.GenreList = client.GetList();
            return View(list);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View("Create");
        }

        [HttpPost]
        public ActionResult Create(GenreModel genre)
        {
            GenreClient client = new GenreClient();
            client.Create(genre);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string genreID)
        {
            GenreClient client = new GenreClient();
            client.Delete(genreID);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(string genreID)
        {
            GenreClient client = new GenreClient();
            GenreModel genre = new GenreModel();
            genre = client.Find(genreID);
            return View("Edit", genre);
        }

        [HttpPost]
        public ActionResult Edit(GenreModel genre)
        {
            GenreClient client = new GenreClient();
            client.Edit(genre);
            return RedirectToAction("Index");
        }


    }
}