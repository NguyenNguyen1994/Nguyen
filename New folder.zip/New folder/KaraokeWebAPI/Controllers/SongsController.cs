﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;
using KaraokeWebAPI.ViewModel;

namespace KaraokeWebAPI.Controllers
{
    public class SongsController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        //// GET: api/Songs
        //public IQueryable<SongCreateViewModel> GetSongs()
        //{
        //    IQueryable<SongCreateViewModel> list;

        //    var query = (from song in db.Songs
        //                join sd in db.SongDetails
        //                on song.SongID equals sd.SongID
        //                select new SongCreateViewModel
        //                {
        //                    SongID = song.SongID,
        //                    SongName = song.SongName,
        //                    GenreID = song.GenreID,
        //                    SingerID = sd.SingerID,
        //                    DateUpload = song.DateUpload,
        //                    ViewsCount = song.ViewsCount
        //                });
        //    list = query.AsQueryable();
        //    return list;
        //    //return db.Songs;
        //}

        public string ConvertToUnsign1(string str)
        {
            string[] signs = new string[] {
            "aAeEoOuUiIdDyY",
            "áàạảãâấầậẩẫăắằặẳẵ",
            "ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",
            "éèẹẻẽêếềệểễ",
            "ÉÈẸẺẼÊẾỀỆỂỄ",
            "óòọỏõôốồộổỗơớờợởỡ",
            "ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",
            "úùụủũưứừựửữ",
            "ÚÙỤỦŨƯỨỪỰỬỮ",
            "íìịỉĩ",
            "ÍÌỊỈĨ",
            "đ",
            "Đ",
            "ýỳỵỷỹ",
            "ÝỲỴỶỸ"
        };
            for (int i = 1; i < signs.Length; i++)
            {
                for (int j = 0; j < signs[i].Length; j++)
                {
                    str = str.Replace(signs[i][j], signs[0][i - 1]);
                }
            }
            return str;
        }

        public List<Singer> GetSingerOfSong(string id)
        {

            var list = from singer in db.Singers
                       join songdt in db.SongDetails
                       on singer.SingerID equals songdt.SingerID
                       where songdt.SongID == id
                       select new Singer()
                       {
                           SingerID = singer.SingerID,
                           SingerName = singer.SingerName
                       };

            //List<Singer> listSinger = new List<Singer>();
            //foreach(var item in list)
            //{
            //    Singer s = new Singer();
            //    s.SingerID = item.SingerID;
            //    s.SingerName = item.SingerName;
            //    listSinger.Add(s);
            //}
            return list.ToList();
        }


        // GET: api/Songs
        public IQueryable<SongViewModel> GetSongs()
        {
            var list = db.Songs.ToList();
            List<SongViewModel> listSVM = new List<SongViewModel>();
            KaraokeViewModelController k = new KaraokeViewModelController();
            
            foreach (var item in list)
            {
                string name = "";
                SongViewModel song = new SongViewModel();
                song.SongID = item.SongID;
                song.SongName = item.SongName;
                song.GenreID = item.GenreID;
                song.DateUpload = item.DateUpload;
                song.ViewsCount = item.ViewsCount;
                song.SongUName = ConvertToUnsign1(item.SongName);
                song.SingerList = k.GetSingerOfSong(item.SongID);
                foreach(var i in song.SingerList)
                {
                    name = name + i.SingerName + " ";
                }
                song.SingerName = ConvertToUnsign1(name);
                listSVM.Add(song);
            }
            return listSVM.AsQueryable();
        }




        // GET: api/Songs/5
        [ResponseType(typeof(Song))]
        public IHttpActionResult GetSong(string songID)
        {
            var query = from song in db.Songs
                        join sd in db.SongDetails
                        on song.SongID equals sd.SongID
                        where song.SongID == songID
                        select new SongCreateViewModel
                        {
                            SongID = song.SongID,
                            SongName = song.SongName,
                            GenreID = song.GenreID,
                            SingerID = sd.SingerID,
                            DateUpload = song.DateUpload,
                            ViewsCount = song.ViewsCount
                        };
            return Ok(query);
        }

        
        // PUT: api/Songs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSong(string id, Song song)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != song.SongID)
            {
                return BadRequest();
            }

            db.Entry(song).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SongExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Songs
        [ResponseType(typeof(Song))]
        public IHttpActionResult PostSong(Song song)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Songs.Add(song);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (SongExists(song.SongID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = song.SongID }, song);
        }

        //// POST: api/Songs
        //[ResponseType(typeof(Song))]
        //public IHttpActionResult PostSong(Song song)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    db.Songs.Add(song);

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateException)
        //    {
        //        if (SongExists(song.SongID))
        //        {
        //            return Conflict();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return CreatedAtRoute("DefaultApi", new { id = song.SongID }, song);
        //}

        // DELETE: api/Songs/5
        [ResponseType(typeof(Song))]
        public IHttpActionResult DeleteSong(string id)
        {
            Song song = db.Songs.Find(id);
            if (song == null)
            {
                return NotFound();
            }

            db.Songs.Remove(song);
            db.SaveChanges();

            return Ok(song);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SongExists(string id)
        {
            return db.Songs.Count(e => e.SongID == id) > 0;
        }
    }
}