﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;

namespace KaraokeWebAPI.Controllers
{
    public class SongDetailsController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/SongDetails
        public IQueryable<SongDetail> GetSongDetails()
        {
            return db.SongDetails;
        }

        // GET: api/SongDetails/5
        [ResponseType(typeof(SongDetail))]
        public IHttpActionResult GetSongDetail(string id)
        {
            SongDetail songDetail = db.SongDetails.Find(id);
            if (songDetail == null)
            {
                return NotFound();
            }

            return Ok(songDetail);
        }

        // PUT: api/SongDetails/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSongDetail(string id, SongDetail songDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != songDetail.SongID)
            {
                return BadRequest();
            }

            db.Entry(songDetail).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SongDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/SongDetails
        [ResponseType(typeof(SongDetail))]
        public IHttpActionResult PostSongDetail(SongDetail songDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.SongDetails.Add(songDetail);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (SongDetailExists(songDetail.SongID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = songDetail.SongID }, songDetail);
        }

        // DELETE: api/SongDetails/5
        [ResponseType(typeof(SongDetail))]
        public IHttpActionResult DeleteSongDetail(string id)
        {
            SongDetail songDetail = db.SongDetails.Find(id);
            if (songDetail == null)
            {
                return NotFound();
            }

            db.SongDetails.Remove(songDetail);
            db.SaveChanges();

            return Ok(songDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SongDetailExists(string id)
        {
            return db.SongDetails.Count(e => e.SongID == id) > 0;
        }
    }
}