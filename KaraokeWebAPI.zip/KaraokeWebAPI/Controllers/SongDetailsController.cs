﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;

namespace KaraokeWebAPI.Controllers
{
    public class SongDetailsController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/SongDetails
        public IQueryable<SongDetail> GetSongDetails()
        {
            return db.SongDetails;
        }

        // GET: api/SongDetails/5
        [ResponseType(typeof(SongDetail))]
        public IQueryable<SongDetail> GetSongDetail(string id)
        {
            //SongDetail songDetail = db.SongDetails.Find(id);
            IQueryable<SongDetail> listSongDetail;

            var songDT = from sdt in db.SongDetails
                         where sdt.SongID == id
                         select sdt;
            listSongDetail = songDT.ToList().AsQueryable();
            return listSongDetail;
        }


        // PUT: api/SongDetails/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSongDetail(string id, SongDetail songDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != songDetail.SongID)
            {
                return BadRequest();
            }

            db.Entry(songDetail).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SongDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/SongDetails
        [ResponseType(typeof(SongDetail))]
        public IHttpActionResult PostSongDetail(SongDetail songDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.SongDetails.Add(songDetail);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (SongDetailExists(songDetail.SongID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = songDetail.SongID }, songDetail);
        }

        //DELETE: api/SongDetails/5
        [ResponseType(typeof(SongDetail))]
        public IHttpActionResult DeleteSongDetail1(string songID, string singerID)
        {
            SongDetail s = db.SongDetails.Where(x => x.SongID == songID && x.SingerID == singerID).FirstOrDefault();
            db.SongDetails.Remove(s);
            db.SaveChanges();
            return Ok(s);
        }

        [ResponseType(typeof(SongDetail))]
        public IHttpActionResult DeleteSongDetail(string songID)
        {
            List<SongDetail> ss = db.SongDetails.Where(x => x.SongID == songID).ToList();
            foreach(SongDetail s in ss)
            {
                db.SongDetails.Remove(s);
            }
            db.SaveChanges();
            return Ok(ss);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SongDetailExists(string id)
        {
            return db.SongDetails.Count(e => e.SongID == id) > 0;
        }
    }
}