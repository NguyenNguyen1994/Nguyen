﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;
using KaraokeWebAPI.ViewModel;

namespace KaraokeWebAPI.Controllers
{
    public class GenresController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/Genres
        public List<Genre> GetGenres()
        {
            return db.Genres.ToList();
        }

        // GET: api/Genres/5
        [ResponseType(typeof(Genre))]
        public IHttpActionResult GetGenre(string id)
        {
            //var sd = db.Admins.

            Genre genre = db.Genres.Find(id);
            if (genre == null)
            {
                return NotFound();
            }

            return Ok(genre);
        }

        //User
        // Lay danh sach bai hat theo the loai
        [HttpGet]
        public IQueryable<KaraokeViewModel> GetSongGenre(string id)
        {
            var list = from song in db.Songs
                       join genre in db.Genres
                       on song.GenreID equals genre.GenreID
                       where song.GenreID == id
                       join songdt in db.SongDetails
                       on song.SongID equals songdt.SongID
                       join singer in db.Singers
                       on songdt.SingerID equals singer.SingerID                      
                       select new KaraokeViewModel()
                       {
                           SongID = song.SongID,
                           SongName = song.SongName,
                           DateUpload = song.DateUpload,
                           GenreID = genre.GenreID,
                           GenreName = genre.GenreName,
                           SingerID = singer.SingerID,
                           SingerName = singer.SingerName
                       };
            return list.OrderBy(x=>x.SongName);
        }

        // PUT: api/Genres/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutGenre(string id, Genre genre)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != genre.GenreID)
            {
                return BadRequest();
            }

            db.Entry(genre).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GenreExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Genres
        [ResponseType(typeof(Genre))]
        public IHttpActionResult PostGenre(Genre genre)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Genres.Add(genre);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (GenreExists(genre.GenreID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = genre.GenreID }, genre);
        }

        // DELETE: api/Genres/5
        [ResponseType(typeof(Genre))]
        public IHttpActionResult DeleteGenre(string id)
        {
            Genre genre = db.Genres.Find(id);
            if (genre == null)
            {
                return NotFound();
            }

            db.Genres.Remove(genre);
            db.SaveChanges();

            return Ok(genre);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool GenreExists(string id)
        {
            return db.Genres.Count(e => e.GenreID == id) > 0;
        }
    }
}