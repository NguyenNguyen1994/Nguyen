﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;

namespace KaraokeWebAPI.Controllers
{
    public class ListSongOfUsersController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/ListSongOfUsers
        public IQueryable<ListSongOfUser> GetListSongOfUsers()
        {
            return db.ListSongOfUsers;
        }

        // GET: api/ListSongOfUsers/5
        [ResponseType(typeof(ListSongOfUser))]
        public IHttpActionResult GetListSongOfUser(string id)
        {
            ListSongOfUser listSongOfUser = db.ListSongOfUsers.Find(id);
            if (listSongOfUser == null)
            {
                return NotFound();
            }

            return Ok(listSongOfUser);
        }

        // PUT: api/ListSongOfUsers/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutListSongOfUser(string id, ListSongOfUser listSongOfUser)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != listSongOfUser.UserAccountID)
            {
                return BadRequest();
            }

            db.Entry(listSongOfUser).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ListSongOfUserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ListSongOfUsers
        [ResponseType(typeof(ListSongOfUser))]
        public IHttpActionResult PostListSongOfUser(ListSongOfUser listSongOfUser)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ListSongOfUsers.Add(listSongOfUser);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (ListSongOfUserExists(listSongOfUser.UserAccountID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = listSongOfUser.UserAccountID }, listSongOfUser);
        }

        // DELETE: api/ListSongOfUsers/5
        [ResponseType(typeof(ListSongOfUser))]
        public IHttpActionResult DeleteListSongOfUser(string id)
        {
            ListSongOfUser listSongOfUser = db.ListSongOfUsers.Find(id);
            if (listSongOfUser == null)
            {
                return NotFound();
            }

            db.ListSongOfUsers.Remove(listSongOfUser);
            db.SaveChanges();

            return Ok(listSongOfUser);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ListSongOfUserExists(string id)
        {
            return db.ListSongOfUsers.Count(e => e.UserAccountID == id) > 0;
        }
    }
}