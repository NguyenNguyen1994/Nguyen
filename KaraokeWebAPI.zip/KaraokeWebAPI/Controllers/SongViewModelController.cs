﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;
using KaraokeWebAPI.ViewModels;

namespace KaraokeWebAPI.Controllers
{
    public class SongViewModelController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/SongViewModels
        public IQueryable<SongViewModel> GetSongViewModels()
        {
            var list = from s in db.Songs
                       join g in db.Genres
                       on s.GenreID equals g.ID
                       select new SongViewModel()
                       {
                           ID = s.ID,
                           Name = s.Name,
                           GenreName = g.Name,
                           DateUpload = s.DateUpload,
                           Views = s.Views,
                       };
            return list;
        }
        /*
        // GET: api/SongViewModels/5
        [ResponseType(typeof(SongViewModel))]
        public IHttpActionResult GetSongViewModel(string id)
        {
            SongViewModel songViewModel = db.SongViewModels.Find(id);
            if (songViewModel == null)
            {
                return NotFound();
            }

            return Ok(songViewModel);
        }

        // PUT: api/SongViewModels/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSongViewModel(string id, SongViewModel songViewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != songViewModel.ID)
            {
                return BadRequest();
            }

            db.Entry(songViewModel).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SongViewModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/SongViewModels
        [ResponseType(typeof(SongViewModel))]
        public IHttpActionResult PostSongViewModel(SongViewModel songViewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.SongViewModels.Add(songViewModel);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (SongViewModelExists(songViewModel.ID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = songViewModel.ID }, songViewModel);
        }

        // DELETE: api/SongViewModels/5
        [ResponseType(typeof(SongViewModel))]
        public IHttpActionResult DeleteSongViewModel(string id)
        {
            SongViewModel songViewModel = db.SongViewModels.Find(id);
            if (songViewModel == null)
            {
                return NotFound();
            }

            db.SongViewModels.Remove(songViewModel);
            db.SaveChanges();

            return Ok(songViewModel);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SongViewModelExists(string id)
        {
            return db.SongViewModels.Count(e => e.ID == id) > 0;
        }
        */
    }
}