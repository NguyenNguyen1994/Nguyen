﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;
using KaraokeWebAPI.ViewModel.User;

namespace KaraokeWebAPI.Controllers
{
    public class UsersController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/Users
        public IQueryable<User> GetUsers()
        {
            return db.Users;
        }

        [HttpGet]
        public IQueryable<ListInfo> GetAllList(string userID)
        {
            var listID = db.ListSongOfUsers.Where(x => x.UserAccountID == userID).Select(x => x.ListID);
            List<ListInfo> listUser = new List<ListInfo>();
            foreach(var item in listID)
            {
                ListInfo l = new ListInfo();
                l.ListID = item;
                l.ListName = db.ListInfoes.Where(x => x.ListID == item).Select(x => x.ListName).FirstOrDefault();
                if(listUser.Select(x=>x.ListID == item).Count() == 0)
                {
                    listUser.Add(l);
                }            
            }
            return listUser.AsQueryable();
        }

        private List<Singer> ListSinger(string songID)
        {
            SongsController song = new SongsController();
            List<Singer> list = new List<Singer>();
            foreach(var item in song.GetSingerOfSong1(songID))
            {
                Singer s = new Singer();
                s.SingerID = item.SingerID;
                s.SingerName = item.SingerName;
                list.Add(s);
            }
            return list;
        }

        [HttpGet]
        public List<SongModel> SongOfList (int listID)
        {
            var listSongID = db.ListSongOfUsers.Where(x => x.ListID == listID).Select(x => x.SongID);
            SongsController song = new SongsController();
            List<SongModel> listSM = new List<SongModel>();
            foreach (var item in listSongID)
            {
                SongModel newSong = new SongModel();
                newSong.SongID = item;
                newSong.SongName = db.Songs.Where(x => x.SongID == item).Select(x => x.SongName).FirstOrDefault();
                newSong.GenreID = db.Songs.Where(x => x.SongID == item).Select(x => x.GenreID).FirstOrDefault();
                newSong.GenreName = db.Genres.Where(x => x.GenreID == newSong.GenreID).Select(x => x.GenreID).FirstOrDefault();
                newSong.ListSinger = ListSinger(item);
                listSM.Add(newSong);
            }
            return listSM;
        }

        [HttpGet]
        public IQueryable<UserListSong> UserList(string userID, int listID)
        {
            SongsController song = new SongsController();
            var listSong = from l in GetAllList(userID)
                           join ldt in db.ListSongOfUsers
                           on l.ListID equals ldt.ListID
                           where ldt.ListID == listID
                           select new UserListSong()
                           {
                               UserID = userID,
                               UserName = db.Users.Where(x => x.AccountID == userID).Select(x => x.Name).FirstOrDefault(),
                               ListID = l.ListID,
                               ListName = l.ListName,
                               ListSong = SongOfList(listID)
                           };
            return listSong;
        }

        //[HttpGet]
        //public IHttpActionResult AddSongToList(string userID, string songID, int listID)
        //{
        //    ListSongOfUsersController ldtController = new ListSongOfUsersController();
        //    ListSongOfUser list = new ListSongOfUser();
        //    list.UserAccountID = userID;
        //    list.ListID = listID;
        //    list.SongID = songID;
        //    ldtController.PostListSongOfUser(list);
        //    return Ok();
        //}

        [HttpPost]
        public IHttpActionResult AddSongToList(string userID, string songID, int listID)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            ListSongOfUser list = new ListSongOfUser();
            try
            {
                list.UserAccountID = userID;
                list.ListID = listID;
                list.SongID = songID;
                db.ListSongOfUsers.Add(list);
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (ListSongOfUserExists(songID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = list.UserAccountID }, list);
        }

        private bool ListSongOfUserExists(string id)
        {
            return db.ListSongOfUsers.Count(e => e.SongID == id) > 0;
        }


        [HttpGet]
        public bool CheckUser(string id, string pass)
        {
            foreach (var item in db.Users)
            {
                if (String.Compare(item.AccountID, id, false) == 0 && item.Password == pass)
                    return true;
            }
            return false;
            //var acc = db.Admins.Count(x => x.ID == id && x.Password == pass);
            //if (acc.Count() <= 0)
            //    return false;
            //return true;
        }
        // GET: api/Users/5
        [ResponseType(typeof(User))]
        public IHttpActionResult GetUser(string id)
        {
            User user = db.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        // PUT: api/Users/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutUser(string id, User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != user.AccountID)
            {
                return BadRequest();
            }

            db.Entry(user).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Users
        [ResponseType(typeof(User))]
        public IHttpActionResult PostUser(User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Users.Add(user);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (UserExists(user.AccountID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = user.AccountID }, user);
        }

        // DELETE: api/Users/5
        [ResponseType(typeof(User))]
        public IHttpActionResult DeleteUser(string id)
        {
            User user = db.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            db.Users.Remove(user);
            db.SaveChanges();

            return Ok(user);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UserExists(string id)
        {
            return db.Users.Count(e => e.AccountID == id) > 0;
        }
    }
}