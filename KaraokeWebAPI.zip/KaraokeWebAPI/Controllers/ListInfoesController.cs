﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;

namespace KaraokeWebAPI.Controllers
{
    public class ListInfoesController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/ListInfoes
        public IQueryable<ListInfo> GetListInfoes()
        {
            return db.ListInfoes;
        }

        // GET: api/ListInfoes/5
        [ResponseType(typeof(ListInfo))]
        public IHttpActionResult GetListInfo(int id)
        {
            ListInfo listInfo = db.ListInfoes.Find(id);
            if (listInfo == null)
            {
                return NotFound();
            }

            return Ok(listInfo);
        }

        // PUT: api/ListInfoes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutListInfo(int id, ListInfo listInfo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != listInfo.ListID)
            {
                return BadRequest();
            }

            db.Entry(listInfo).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ListInfoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ListInfoes
        [ResponseType(typeof(ListInfo))]
        public IHttpActionResult PostListInfo(ListInfo listInfo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ListInfoes.Add(listInfo);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = listInfo.ListID }, listInfo);
        }

        // DELETE: api/ListInfoes/5
        [ResponseType(typeof(ListInfo))]
        public IHttpActionResult DeleteListInfo(int id)
        {
            ListInfo listInfo = db.ListInfoes.Find(id);
            if (listInfo == null)
            {
                return NotFound();
            }

            db.ListInfoes.Remove(listInfo);
            db.SaveChanges();

            return Ok(listInfo);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ListInfoExists(int id)
        {
            return db.ListInfoes.Count(e => e.ListID == id) > 0;
        }
    }
}