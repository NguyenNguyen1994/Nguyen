﻿using KaraokeWebAPI.Models;
using KaraokeWebAPI.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KaraokeWebAPI.Controllers
{
    public class SongCRUDController : ApiController
    {
        KaraokeModel db = new KaraokeModel();

        // GET: api/Songs
        public IQueryable<SongCRUDViewModel> GetSongs()
        {
            IQueryable<SongCRUDViewModel> list;

            var query = from song in db.Songs
                        join sd in db.SongDetails
                        on song.SongID equals sd.SongID
                        join singer in db.Singers
                        on sd.SingerID equals singer.SingerID
                        select new SongCRUDViewModel
                        {
                            SongID = song.SongID,
                            SongName = song.SongName,
                            GenreID = song.GenreID,
                            SingerID = sd.SingerID,
                            DateUpload = song.DateUpload,
                            ViewsCount = song.ViewsCount
                        };
            list = query.AsQueryable();
            return list;
            //return db.Songs;
        }
    }
}
