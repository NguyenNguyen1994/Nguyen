﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;
using KaraokeWebAPI.ViewModel;

namespace KaraokeWebAPI.Controllers
{
    public class SingersController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/Singers
        public IQueryable<Singer> GetSingers()
        {
            return db.Singers;
        }

        // GET: api/Singers/5
        [ResponseType(typeof(Singer))]
        public IHttpActionResult GetSinger(string id)
        {
            Singer singer = db.Singers.Find(id);
            if (singer == null)
            {
                return NotFound();
            }

            return Ok(singer);
        }


        public IQueryable<SongOfSingerViewModel> GetAllSong(string id)
        {
            var listSong = from s in db.Songs
                           join sdt in db.SongDetails
                           on s.SongID equals sdt.SongID
                           where sdt.SingerID == id
                           select new SongOfSingerViewModel
                           {
                               SongID = s.SongID,
                               SongName = s.SongName
                           };
            return listSong;
        }

        //User
        //Lay danh sach bai hat cua ca si
        [HttpGet]
        public IQueryable<KaraokeViewModel> GetSongSinger(string id)
        {

            var list = from song in db.Songs
                       join songdt in db.SongDetails
                       on song.SongID equals songdt.SongID
                       join singer in db.Singers
                       on songdt.SingerID equals singer.SingerID
                       where singer.SingerID == id
                       join genre in db.Genres
                       on song.GenreID equals genre.GenreID
                       select new KaraokeViewModel()
                       {
                           SongID = song.SongID,
                           SongName = song.SongName,
                           DateUpload = song.DateUpload,
                           GenreID = genre.GenreID,
                           GenreName = genre.GenreName,
                           SingerID = singer.SingerID,
                           SingerName = singer.SingerName
                       };
            return list.OrderBy(x => x.SongName);
        }



        // PUT: api/Singers/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSinger(string id, Singer singer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != singer.SingerID)
            {
                return BadRequest();
            }

            db.Entry(singer).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SingerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Singers
        [ResponseType(typeof(Singer))]
        public IHttpActionResult PostSinger(Singer singer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Singers.Add(singer);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (SingerExists(singer.SingerID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = singer.SingerID }, singer);
        }

        // DELETE: api/Singers/5
        [ResponseType(typeof(Singer))]
        public IHttpActionResult DeleteSinger(string id)
        {
            Singer singer = db.Singers.Find(id);
            if (singer == null)
            {
                return NotFound();
            }

            db.Singers.Remove(singer);
            db.SaveChanges();

            return Ok(singer);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SingerExists(string id)
        {
            return db.Singers.Count(e => e.SingerID == id) > 0;
        }
    }
}