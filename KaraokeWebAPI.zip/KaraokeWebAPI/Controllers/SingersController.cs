﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KaraokeWebAPI.Models;

namespace KaraokeWebAPI.Controllers
{
    public class SingersController : ApiController
    {
        private KaraokeModel db = new KaraokeModel();

        // GET: api/Singers
        public IQueryable<Singer> GetSingers()
        {
            return db.Singers;
        }

        // GET: api/Singers/5
        [ResponseType(typeof(Singer))]
        public IHttpActionResult GetSinger(string id)
        {
            Singer singer = db.Singers.Find(id);
            if (singer == null)
            {
                return NotFound();
            }

            return Ok(singer);
        }

        // PUT: api/Singers/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSinger(string id, Singer singer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != singer.ID)
            {
                return BadRequest();
            }

            db.Entry(singer).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SingerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Singers
        [ResponseType(typeof(Singer))]
        public IHttpActionResult PostSinger(Singer singer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Singers.Add(singer);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (SingerExists(singer.ID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = singer.ID }, singer);
        }

        // DELETE: api/Singers/5
        [ResponseType(typeof(Singer))]
        public IHttpActionResult DeleteSinger(string id)
        {
            Singer singer = db.Singers.Find(id);
            if (singer == null)
            {
                return NotFound();
            }

            db.Singers.Remove(singer);
            db.SaveChanges();

            return Ok(singer);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SingerExists(string id)
        {
            return db.Singers.Count(e => e.ID == id) > 0;
        }
    }
}