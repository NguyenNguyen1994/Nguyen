﻿using KaraokeWebAPI.Models;
using KaraokeWebAPI.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KaraokeWebAPI.Controllers
{
    public class KaraokeViewModelController : ApiController
    {
        KaraokeModel db = new KaraokeModel();
        //User
        //Lay danh sach bai hat

        [HttpGet]
        [ActionName("listsong")]
        public IQueryable<KaraokeViewModel> GetListSong()
        {
            var list = from song in db.Songs
                       join songdt in db.SongDetails
                       on song.SongID equals songdt.SongID
                       join singer in db.Singers
                       on songdt.SingerID equals singer.SingerID
                       join genre in db.Genres
                       on song.GenreID equals genre.GenreID
                       select new KaraokeViewModel()
                       {
                           SongID = song.SongID,
                           SongName = song.SongName,
                           DateUpload = song.DateUpload,
                           GenreID = genre.GenreID,
                           GenreName = genre.GenreName,
                           SingerID = singer.SingerID,
                           SingerName = singer.SingerName
                       };
            return list.OrderBy(x => x.SongName);
        }

        //User
        // Lay danh sach bai hat theo the loai
        [HttpGet]
        public IQueryable<KaraokeViewModel> GetSongGenre(string id)
        {
            var list = from song in db.Songs
                       join genre in db.Genres
                       on song.GenreID equals genre.GenreID
                       where song.GenreID == id
                       join songdt in db.SongDetails
                       on song.SongID equals songdt.SongID
                       join singer in db.Singers
                       on songdt.SingerID equals singer.SingerID
                       select new KaraokeViewModel()
                       {
                           SongID = song.SongID,
                           SongName = song.SongName,
                           DateUpload = song.DateUpload,
                           GenreID = genre.GenreID,
                           GenreName = genre.GenreName,
                           SingerID = singer.SingerID,
                           SingerName = singer.SingerName
                       };
            return list.OrderBy(x => x.SongName);
        }

        //User
        //Lay danh sach bai hat cua ca si
        [HttpGet]
        public IQueryable<KaraokeViewModel> GetSongSinger(string id)
        {

            var list = from song in db.Songs
                       join songdt in db.SongDetails
                       on song.SongID equals songdt.SongID
                       join singer in db.Singers
                       on songdt.SingerID equals singer.SingerID
                       where singer.SingerID == id
                       join genre in db.Genres
                       on song.GenreID equals genre.GenreID
                       select new KaraokeViewModel()
                       {
                           SongID = song.SongID,
                           SongName = song.SongName,
                           DateUpload = song.DateUpload,
                           GenreID = genre.GenreID,
                           GenreName = genre.GenreName,
                           SingerID = singer.SingerID,
                           SingerName = singer.SingerName
                       };
            return list.OrderBy(x => x.SongName);
        }      

        [HttpGet]
        [ActionName("listnewsong")]
        public List<KaraokeViewModel> GetListNewSong()
        {
            List<KaraokeViewModel> list = new List<KaraokeViewModel>();
            list = db.Database.SqlQuery<KaraokeViewModel>("select * from GetNewSong()").ToList();
            return list;
        }


        public List<Singer> GetSingerOfSong(string id)
        {
            var list = from song in db.Songs
                       join songdt in db.SongDetails
                       on song.SongID equals songdt.SongID
                       where song.SongID == id
                       join singer in db.Singers
                       on songdt.SingerID equals singer.SingerID
                       join genre in db.Genres
                       on song.GenreID equals genre.GenreID
                       select new KaraokeViewModel()
                       {
                           SongID = song.SongID,
                           SongName = song.SongName,
                           DateUpload = song.DateUpload,
                           GenreID = genre.GenreID,
                           GenreName = genre.GenreName,
                           SingerID = singer.SingerID,
                           SingerName = singer.SingerName
                       };

            List<Singer> listSinger = new List<Singer>();
            foreach(var item in list)
            {
                Singer s = new Singer();
                s.SingerID = item.SingerID;
                s.SingerName = item.SingerName;
                listSinger.Add(s);
            }
            return listSinger;
        }

    }
}
