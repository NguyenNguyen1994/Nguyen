namespace KaraokeWebAPI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ListInfo")]
    public partial class ListInfo
    {
        [Key]
        public int ListID { get; set; }

        [StringLength(150)]
        public string ListName { get; set; }

        [StringLength(150)]
        public string Description { get; set; }
    }
}
