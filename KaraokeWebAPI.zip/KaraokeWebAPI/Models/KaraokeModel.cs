namespace KaraokeWebAPI.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class KaraokeModel : DbContext
    {
        public KaraokeModel()
            : base("name=KaraokeModel")
        {
        }

        public virtual DbSet<Admin> Admins { get; set; }
        public virtual DbSet<Genre> Genres { get; set; }
        public virtual DbSet<Singer> Singers { get; set; }
        public virtual DbSet<Song> Songs { get; set; }
        public virtual DbSet<SongDetail> SongDetails { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>()
                .Property(e => e.ID)
                .IsUnicode(false);

            modelBuilder.Entity<Admin>()
                .Property(e => e.Password)
                .IsUnicode(false);

            modelBuilder.Entity<Genre>()
                .Property(e => e.GenreID)
                .IsUnicode(false);

            modelBuilder.Entity<Singer>()
                .Property(e => e.SingerID)
                .IsUnicode(false);

            modelBuilder.Entity<Song>()
                .Property(e => e.SongID)
                .IsUnicode(false);

            modelBuilder.Entity<Song>()
                .Property(e => e.GenreID)
                .IsUnicode(false);

            modelBuilder.Entity<SongDetail>()
                .Property(e => e.SongID)
                .IsUnicode(false);

            modelBuilder.Entity<SongDetail>()
                .Property(e => e.SingerID)
                .IsUnicode(false);
        }
    }
}
