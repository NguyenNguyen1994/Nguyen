namespace KaraokeWebAPI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ListSongOfUser")]
    public partial class ListSongOfUser
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string UserAccountID { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ListID { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string SongID { get; set; }
    }
}
