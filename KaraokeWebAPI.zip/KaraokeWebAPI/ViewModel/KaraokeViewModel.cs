﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI.ViewModel
{
    public class KaraokeViewModel
    {
        public string GenreID { get; set; }
        public string GenreName { get; set; }
        //
        public string SongID { get; set; }
        public string SongName { get; set; }
        public DateTime? DateUpload { get; set; }
        //
        public string SingerID { get; set; }
        public string SingerName { get; set; }
    }
}