﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI.ViewModel
{
    public class SongCreateViewModel
    {

        [StringLength(50)]
        public string SongID { get; set; }

        [StringLength(50)]
        public string SongName { get; set; }

        [StringLength(50)]
        public string GenreID { get; set; }

        public DateTime? DateUpload { get; set; }

        public int? ViewsCount { get; set; }

        [StringLength(50)]
        public string SingerID { get; set; }
    }
}