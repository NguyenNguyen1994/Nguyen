﻿using KaraokeWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI.ViewModel.User
{
    public class SongModel
    {
        public string SongID { get; set; }

        public string SongName { get; set; }

        public string GenreID { get; set; }

        public string GenreName { get; set; }

        public List<Singer> ListSinger { get; set; }
    }
}