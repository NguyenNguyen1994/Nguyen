﻿using KaraokeWebAPI_Client.Areas.Admin.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI_Client.Areas.Admin.Models
{
    public class SongModel
    {
        [Required]
        public string SongID { get; set; }

        [Required]
        public string SongName { get; set; }

        public string GenreID { get; set; }

        public DateTime? DateUpload { get; set; }

        public int? ViewsCount { get; set; }
    }
}