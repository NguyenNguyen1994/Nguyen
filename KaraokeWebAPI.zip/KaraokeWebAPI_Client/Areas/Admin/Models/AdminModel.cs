﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace KaraokeWebAPI_Client.Areas.Admin.Models
{
    public class AdminModel
    {
        [Required]
        public string ID { get; set; }

        [Required]
        public string Password { get; set; }

        public string Name { get; set; }

        public bool RemmemberME { get; set; }
    }
}