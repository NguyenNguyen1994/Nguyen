﻿/// <reference path="../angular.min.js" />
/// <reference path="Modules.js" /> 
app.service("CRUD_AngularJs_RESTService", function ($http) {

    this.getAllSinger = function () {
        return $http.get("http://localhost:49891/api/singers");
    }

    this.getAllSong = function (SingerID) {
        return $http.get("http://localhost:49891/api/singers/GetAllSong/" + SingerID);
    }
})