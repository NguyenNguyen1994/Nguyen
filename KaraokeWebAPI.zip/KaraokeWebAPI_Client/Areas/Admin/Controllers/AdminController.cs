﻿using KaraokeWebAPI_Client.Areas.Admin.BAL;
using KaraokeWebAPI_Client.Areas.Admin.Models;
using KaraokeWebAPI_Client.Areas.Admin.ViewModel;
using KaraokeWebAPI_Client.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace KaraokeWebAPI_Client.Areas.Admin.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin/Admin
        public ActionResult Index()
        {           
            return View();
        }

        public ActionResult Login(AdminModel admin)
        {
            if(ModelState.IsValid)
            {
                admin.Password = Encryptor.MD5Hash(admin.Password);
                AdminClient adminClient = new AdminClient();
                bool result = adminClient.Check(admin);
                if (result)
                {
                    var userSession = new UserLogin();
                    userSession.ID = admin.ID;
                    userSession.Name = adminClient.Find(admin.ID).Name;
                    Session.Add(CommonConstants.USER_SESSION, userSession);
                    FormsAuthentication.SetAuthCookie(admin.Name, false);
                    return RedirectToAction("Index", "Song");
                }
                else
                {
                    ModelState.AddModelError("", "Login Error !!");
                }
            }
            return View("Index");       
        }
    }
}