﻿using KaraokeWebAPI_Client.Areas.Admin.BAL;
using KaraokeWebAPI_Client.Areas.Admin.Models;
using KaraokeWebAPI_Client.Areas.Admin.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using PagedList.Mvc;

namespace KaraokeWebAPI_Client.Areas.Admin.Controllers
{
    
    public class GenreController : BaseController
    {
        //// GET: Genre
        //public ActionResult Index()
        //{
        //    GenreClient client = new GenreClient();
        //    GenreListViewModel list = new GenreListViewModel();
        //    list.GenreList = client.GetList();
        //    return View(list);
        //}
        public ActionResult Index()
        {
            return View(this.GenreListP(1));
        }

        [HttpPost]
        public ActionResult Index(int currentPageIndex)
        {
            return View(this.GenreListP(currentPageIndex));
        }

        private GenreListViewModel GenreListP(int currentPage)
        {
            int maxRows = 2;
            GenreClient client = new GenreClient();
            GenreListViewModel generModel = new GenreListViewModel();
            generModel.GenreList = (from genre in client.GetList()
                                    select genre)
                        .OrderBy(genre => genre.GenreName)
                        .Skip((currentPage - 1) * maxRows)
                        .Take(maxRows).ToList();

            double pageCount = (double)((decimal)client.GetList().Count() / Convert.ToDecimal(maxRows));
            generModel.PageCount = (int)Math.Ceiling(pageCount);

            generModel.CurrentPageIndex = currentPage;

            return generModel;
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View("Create");
        }

        [HttpPost]
        public ActionResult Create(GenreModel genre)
        {
            GenreClient client = new GenreClient();
            client.Create(genre);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string genreID)
        {
            GenreClient client = new GenreClient();
            client.Delete(genreID);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(string genreID)
        {
            GenreClient client = new GenreClient();
            GenreModel genre = new GenreModel();
            genre = client.Find(genreID);
            return View("Edit", genre);
        }

        [HttpPost]
        public ActionResult Edit(GenreModel genre)
        {
            GenreClient client = new GenreClient();
            client.Edit(genre);
            return RedirectToAction("Index");
        }


    }
}