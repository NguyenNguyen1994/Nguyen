﻿using KaraokeWebAPI_Client.Areas.Admin.BAL;
using KaraokeWebAPI_Client.Areas.Admin.Models;
using KaraokeWebAPI_Client.Areas.Admin.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using PagedList.Mvc;

namespace KaraokeWebAPI_Client.Areas.Admin.Controllers
{
    
    public class SongController : BaseController
    {
        //GET: Genre
        //public ActionResult Index()
        //{
        //    SongClient client = new SongClient();
        //    SongCreateListViewModel listS = new SongCreateListViewModel();
        //    var list = client.GetList();
        //    List<SongModel> listSong = new List<SongModel>();
        //    foreach (var item in list)
        //    {
        //        SongModel s = new SongModel();
        //        s.SongID = item.SongID;
        //        s.SongName = item.SongName;
        //        s.GenreID = item.GenreID;
        //        s.DateUpload = item.DateUpload;
        //        s.ViewsCount = item.ViewsCount;
        //        listSong.Add(s);
        //    }
        //    listSong.OrderBy(x => x.SongName).GroupBy(x => x.SongName);
        //    listS.SongList = listSong.ToList().OrderBy(x => x.SongName);


        //    GenreClient genreClient = new GenreClient();
        //    ViewBag.listGenre = genreClient.GetList();

        //    SingerClient singerClient = new SingerClient();
        //    SongDetailClient sdtClient = new SongDetailClient();

        //    var lsitSingerOfSong = from singer in singerClient.GetList()
        //                           join sdt in sdtClient.GetList()
        //                           on singer.SingerID equals sdt.SingerID
        //                           join song in client.GetList()
        //                           on sdt.SongID equals song.SongID
        //                           select new SingerOfSongViewModel
        //                           {
        //                               SongID = song.SongID,
        //                               SingerName = singer.SingerName,
        //                               SingerID = singer.SingerID
        //                           };
        //    listS.ListSingerOfSong = lsitSingerOfSong;
        //    return View(listS);
        //}
        public ActionResult Index()
        {
            GenreClient genreClient = new GenreClient();
            ViewBag.listGenre = genreClient.GetList();
            return View(this.SongListP(1));
        }

        [HttpPost]
        public ActionResult Index(int currentPageIndex)
        {
            GenreClient genreClient = new GenreClient();
            ViewBag.listGenre = genreClient.GetList();
            return View(this.SongListP(currentPageIndex));
        }

        private SongCreateListViewModel SongListP(int currentPage)
        {
            int maxRows = 4;
            SongClient client = new SongClient();
            SongCreateListViewModel songModel = new SongCreateListViewModel();
            songModel.SongList = (from song in client.GetAll()
                                  select song)
                                  .OrderBy(song => song.SongName)
                        .Skip((currentPage - 1) * maxRows)
                        .Take(maxRows).ToList();

            double pageCount = (double)((decimal)client.GetAll().Count() / Convert.ToDecimal(maxRows));
            songModel.PageCount = (int)Math.Ceiling(pageCount);
            songModel.CurrentPageIndex = currentPage;
            //

            SingerClient singerClient = new SingerClient();
            SongDetailClient sdtClient = new SongDetailClient();

            var lsitSingerOfSong = from singer in singerClient.GetList()
                                   join sdt in sdtClient.GetList()
                                   on singer.SingerID equals sdt.SingerID
                                   join song in songModel.SongList
                                   on sdt.SongID equals song.SongID
                                   select new SingerOfSongViewModel
                                   {
                                       SongID = song.SongID,
                                       SingerName = singer.SingerName,
                                       SingerID = singer.SingerID
                                   };
            songModel.ListSingerOfSong = lsitSingerOfSong;
            return songModel;
        }



        [HttpGet]
        public ActionResult Create()
        {
            SingerClient singerClient = new SingerClient();
            ViewBag.SingerList = singerClient.GetList().OrderBy(x => x.SingerName);
            //
            GenreClient genreClient = new GenreClient();
            ViewBag.GenreList = genreClient.GetList().OrderBy(x => x.GenreName);
            return View("Create");
        }

        [HttpPost]
        public ActionResult Create(SongModel song, string _listID, string _genreID)
        {
            song.DateUpload = DateTime.Now;
            song.ViewsCount = 0;
            song.GenreID = _genreID;
            SongClient client = new SongClient();
            client.Create(song);
            //
            SongDetailController sdtController = new SongDetailController();
            sdtController.Create(song.SongID, _listID);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string songID)
        {
            SongDetailClient sdtclient = new SongDetailClient();
            sdtclient.Delete(songID);
            //
            SongClient client = new SongClient();
            client.Delete(songID);
            return RedirectToAction("Index");
        }

        public string ConvertToUnsign1(string str)
        {
            string[] signs = new string[] {
            "aAeEoOuUiIdDyY",
            "áàạảãâấầậẩẫăắằặẳẵ",
            "ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",
            "éèẹẻẽêếềệểễ",
            "ÉÈẸẺẼÊẾỀỆỂỄ",
            "óòọỏõôốồộổỗơớờợởỡ",
            "ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",
            "úùụủũưứừựửữ",
            "ÚÙỤỦŨƯỨỪỰỬỮ",
            "íìịỉĩ",
            "ÍÌỊỈĨ",
            "đ",
            "Đ",
            "ýỳỵỷỹ",
            "ÝỲỴỶỸ"
        };
            for (int i = 1; i < signs.Length; i++)
            {
                for (int j = 0; j < signs[i].Length; j++)
                {
                    str = str.Replace(signs[i][j], signs[0][i - 1]);
                }
            }
            return str;
        }


        private ActionResult Seacrh(string search = "")
        {
            SongClient client = new SongClient();
            SongCreateListViewModel listS = new SongCreateListViewModel();
            var list = client.GetList();
            List<SongModel> listSong = new List<SongModel>();
            foreach (var item in list)
            {
                SongModel s = new SongModel();
                s.SongID = item.SongID;
                s.SongName = item.SongName;
                s.GenreID = item.GenreID;
                s.DateUpload = item.DateUpload;
                s.ViewsCount = item.ViewsCount;
                listSong.Add(s);
            }
            listSong.OrderBy(x => x.SongName).GroupBy(x => x.SongName);
            listS.SongList = listSong.ToList().OrderBy(x => x.SongName);
            //
            SingerClient singerClient = new SingerClient();
            SongDetailClient sdtClient = new SongDetailClient();
            //
            GenreClient genreClient = new GenreClient();
            ViewBag.listGenre = genreClient.GetList();
            //Tim kiem theo ten bai hat
                listS.SongList = listS.SongList.Where(x => ConvertToUnsign1(x.SongName.ToLower()).Contains(ConvertToUnsign1(search).ToLower())).ToList();
                var lsitSingerOfSong = from singer in singerClient.GetList()
                                       join sdt in sdtClient.GetList()
                                       on singer.SingerID equals sdt.SingerID
                                       join song in listS.SongList
                                       on sdt.SongID equals song.SongID
                                       select new SingerOfSongViewModel
                                       {
                                           SongID = song.SongID,
                                           SingerName = singer.SingerName,
                                           SingerID = singer.SingerID
                                       };
                listS.ListSingerOfSong = lsitSingerOfSong;
            if (listS.SongList.Count() != 0)
            {
                return View("Index", listS);
            }
            else
            {
                var lists = from singer in singerClient.GetList()
                            join sdt in sdtClient.GetList()
                            on singer.SingerID equals sdt.SingerID
                            where ConvertToUnsign1(singer.SingerName.ToLower()).Contains(ConvertToUnsign1(search).ToLower())
                            join song in client.GetList()
                            on sdt.SongID equals song.SongID
                            select new SongModel()
                            {
                                SongID = song.SongID,
                                SongName = song.SongName,
                                GenreID = song.GenreID,
                                DateUpload = song.DateUpload,
                                ViewsCount = song.ViewsCount
                            };
                listS.SongList = lists.OrderBy(x => x.SongName);
                //
                var lof = from singer in singerClient.GetList()
                                       join sdt in sdtClient.GetList()
                                       on singer.SingerID equals sdt.SingerID
                                       join song in listS.SongList
                                       on sdt.SongID equals song.SongID
                                       select new SingerOfSongViewModel
                                       {
                                           SongID = song.SongID,
                                           SingerName = singer.SingerName,
                                           SingerID = singer.SingerID
                                       };
                listS.ListSingerOfSong = lof;

                return View("Index", listS);
            }
        }
    }
}