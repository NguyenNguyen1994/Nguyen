﻿using KaraokeWebAPI_Client.Areas.Admin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace KaraokeWebAPI_Client.Areas.Admin.BAL
{
    public class UserClient
    {
        private string _baseURL = "http://localhost:49891/api/";

        public IEnumerable<UserModel> GetList()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Users").Result;
                if (response.IsSuccessStatusCode)
                {
                    return response.Content.ReadAsAsync<IEnumerable<UserModel>>().Result;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
        }

        public UserModel Find(string userID)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Users/GetUser/" + userID).Result;
                if (response.IsSuccessStatusCode)
                {
                    return response.Content.ReadAsAsync<UserModel>().Result;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
        }

        public bool Create(UserModel user)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PostAsJsonAsync("Users/PostUser", user).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        public bool Edit(UserModel user)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PutAsJsonAsync("Users/PutUser/" + user.AccountID, user).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        public bool Delete(string userID)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("Users/DeleteUser/" + userID).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        public bool Check(UserModel user)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_baseURL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Admins/CheckUser?id=" + user.AccountID + "&pass=" + user.Password).Result;
                if (response.IsSuccessStatusCode)
                {
                    return response.Content.ReadAsAsync<bool>().Result;
                }
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
    }
}