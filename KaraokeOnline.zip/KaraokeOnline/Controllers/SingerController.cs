﻿using KaraokeOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KaraokeOnline.Controllers
{
    public class SingerController : ApiController
    {
        KaraokeData db = new KaraokeData();

        [HttpGet]
        public IEnumerable<Singer> GetSingerList()
        {
            return db.Singers.ToList();
        }

        [HttpGet]
        public IHttpActionResult GetSingerByID(string id)
        {
            var singer = db.Singers.FirstOrDefault(x => x.ID == id);
            if (singer != null)
                return Ok(singer);
            else
                return NotFound();
        }


    }
}
